plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}
android {
    namespace = "com.shop.orders"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.shop.orders"
        minSdk = 26
        targetSdk = 34
        versionCode = 7
        versionName = "4.0"
    }
    signingConfigs {
        create("yup") {
            storeFile = file("../yup.jks")
            storePassword = "yup12345"
            keyAlias = "yup"
            keyPassword = "yup12345"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("yup") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-messaging")
}
