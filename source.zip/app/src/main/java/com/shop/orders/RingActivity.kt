package com.shop.orders

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class RingActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setBackgroundColor(0xFF0F5132.toInt())
        l.setPadding(60, 60, 60, 60)
        val t = TextView(this)
        t.text = intent.getStringExtra("txt") ?: "New order"
        t.textSize = 30f
        t.setTextColor(Color.WHITE)
        t.gravity = Gravity.CENTER
        val o = Button(this)
        o.text = "OPEN ORDERS"
        o.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }
        val s = Button(this)
        s.text = "SILENCE"
        s.setOnClickListener {
            startService(Intent(this, RingService::class.java).setAction("STOP"))
            finish()
        }
        l.addView(t); l.addView(o); l.addView(s)
        setContentView(l)
        tick()
    }

    private fun tick() {
        if (!RingService.active) { finish(); return }
        h.postDelayed({ tick() }, 1000)
    }
}
