package com.shop.orders

import android.content.Intent
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class Push : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Cfg.registerAll(this, token)
    }

    override fun onMessageReceived(m: RemoteMessage) {
        val d = m.data
        val i = Intent(this, RingService::class.java)
            .putExtra("test", d["type"] == "test")
            .putExtra("id", d["id"] ?: "")
            .putExtra("total", d["total"] ?: "")
            .putExtra("shop", d["shop"] ?: "")
        startForegroundService(i)
    }
}
