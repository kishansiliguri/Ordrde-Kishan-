package com.shop.orders

import android.content.Intent
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class Push : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        Cfg.registerAll(this, token)
    }

    override fun onMessageReceived(m: RemoteMessage) {
        val d = m.data
        if (d["type"] == "stop") {
            // another phone handled the order: re-check all shops (another shop may still be waiting)
            if (RingService.active) startService(Intent(this, RingService::class.java).setAction("RECHECK"))
            return
        }
        if (Cfg.muted(this)) return                              // alerts are switched off on this phone
        if (!Cfg.hasHost(this, d["host"] ?: "")) return          // this phone is not logged in to that shop
        val i = Intent(this, RingService::class.java)
            .putExtra("test", d["type"] == "test")
            .putExtra("id", d["id"] ?: "")
            .putExtra("total", d["total"] ?: "")
            .putExtra("shop", d["shop"] ?: "")
        startForegroundService(i)
    }
}
