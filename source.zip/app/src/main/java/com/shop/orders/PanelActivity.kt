package com.shop.orders

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

class PanelBridge(private val pin: String) {
    @JavascriptInterface
    fun getPin(): String = pin
}

class PanelActivity : Activity() {
    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = Cfg.shop(this, intent.getStringExtra("id") ?: "")
        if (s == null) { finish(); return }
        val base = s.getString("url")
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val bar = TextView(this)
        bar.text = "\u2190  " + s.getString("name")
        bar.textSize = 18f
        bar.setTextColor(Color.WHITE)
        bar.setBackgroundColor(0xFF0F5132.toInt())
        bar.setPadding(40, 36, 40, 36)
        bar.setOnClickListener { finish() }
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(PanelBridge(s.getString("pin")), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.toString().startsWith(base)) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        root.addView(bar)
        root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        w.loadUrl(base + "/" + s.getString("panel"))
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }
}
