package com.shop.orders

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView

class PanelBridge(private val pin: String) {
    @JavascriptInterface
    fun getPin(): String = pin
}

class PanelActivity : Activity() {
    private var web: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val s = Cfg.shop(this, intent.getStringExtra("id") ?: "")
        if (s == null) { finish(); return }
        val base = s.getString("url")
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        val bar = TextView(this)
        bar.text = "\u2190  " + s.getString("name")
        bar.textSize = 18f
        bar.setTextColor(Color.WHITE)
        bar.setBackgroundColor(0xFF0F5132.toInt())
        bar.setPadding(40, 36, 40, 36)
        bar.setOnClickListener { finish() }
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(PanelBridge(s.getString("pin")), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpError(v: WebView, r: WebResourceRequest, e: WebResourceResponse) {
                if (r.isForMainFrame && e.statusCode >= 400) showErr(v, "Page not found (error " + e.statusCode + ")", r.url.toString())
            }

            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) showErr(v, "Could not load the page. Check your internet.", r.url.toString())
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.toString().startsWith(base)) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        root.addView(bar)
        root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        var pg = s.optString("panel").trim().trimStart('/')
        if (!pg.contains('.')) pg += ".html"
        w.loadUrl(base + "/" + pg)
    }

    private fun showErr(v: WebView, msg: String, url: String) {
        v.loadDataWithBaseURL(null, "<body style='font-family:sans-serif;padding:24px'><h3>" + msg + "</h3><p style='word-break:break-all;color:#666'>" + url + "</p><p>Go back, tap the three dots on the shop and choose Edit to fix the admin page name.</p></body>", "text/html", "utf-8", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }
}
