package com.shop.orders

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Cfg {
    // Change PAGE if you rename the admin file on Hostinger
    const val SITE = "https://skyblue-mandrill-752841.hostingersite.com"
    const val PAGE = "Kishan.html"

    fun prefs(c: Context) = c.getSharedPreferences("p", 0)
    fun pin(c: Context): String = prefs(c).getString("pin", "") ?: ""

    fun api(pin: String, action: String, vararg kv: Pair<String, String>): String? {
        return try {
            val cn = URL("$SITE/save.php").openConnection() as HttpURLConnection
            cn.requestMethod = "POST"
            cn.doOutput = true
            cn.connectTimeout = 8000
            cn.readTimeout = 8000
            val body = (listOf("action" to action, "pin" to pin) + kv.toList())
                .joinToString("&") { URLEncoder.encode(it.first, "UTF-8") + "=" + URLEncoder.encode(it.second, "UTF-8") }
            cn.outputStream.use { it.write(body.toByteArray()) }
            val s = if (cn.responseCode < 400) cn.inputStream else cn.errorStream
            s.bufferedReader().readText()
        } catch (e: Exception) {
            null
        }
    }
}
