package com.shop.orders

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Cfg {
    fun prefs(c: Context) = c.getSharedPreferences("yup", 0)

    // alerts switched off on this phone (-1 = until turned on, otherwise a time in the future)
    fun muted(c: Context): Boolean {
        val u = prefs(c).getLong("mute", 0L)
        return u == -1L || u > System.currentTimeMillis()
    }

    // does this phone have the shop that sent the alert? (no shop saved = no ring)
    fun hasHost(c: Context, host: String): Boolean {
        if (host.isEmpty()) return true
        val h = host.removePrefix("www.").lowercase()
        val a = shops(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("url").lowercase().replace("://www.", "://").contains(h)) return true
        return false
    }

    fun shops(c: Context): JSONArray =
        try { JSONArray(prefs(c).getString("shops", "[]")) } catch (e: Exception) { JSONArray() }

    fun saveShops(c: Context, a: JSONArray) {
        prefs(c).edit().putString("shops", a.toString()).apply()
    }

    fun shop(c: Context, id: String): JSONObject? {
        val a = shops(c)
        for (i in 0 until a.length()) if (a.getJSONObject(i).getString("id") == id) return a.getJSONObject(i)
        return null
    }

    fun api(base: String, pin: String, action: String, kv: Map<String, String> = emptyMap()): String? {
        return try {
            val cn = URL(base.trimEnd('/') + "/save.php").openConnection() as HttpURLConnection
            cn.requestMethod = "POST"
            cn.doOutput = true
            cn.connectTimeout = 8000
            cn.readTimeout = 8000
            val body = (mapOf("action" to action, "pin" to pin) + kv).entries
                .joinToString("&") { URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8") }
            cn.outputStream.use { it.write(body.toByteArray()) }
            val s = if (cn.responseCode < 400) cn.inputStream else cn.errorStream
            s.bufferedReader().readText()
        } catch (e: Exception) {
            null
        }
    }

    // Tell every saved shop about this phone so it can send push alerts here
    fun registerAll(c: Context, token: String) {
        val a = shops(c)
        Thread {
            for (i in 0 until a.length()) {
                val s = a.getJSONObject(i)
                api(s.getString("url"), s.getString("pin"), "regtoken", mapOf("token" to token))
            }
        }.start()
    }
}
