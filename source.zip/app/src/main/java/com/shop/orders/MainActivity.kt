package com.shop.orders

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : Activity() {
    private var web: WebView? = null

    inner class Bridge {
        @JavascriptInterface
        fun getPin(): String = Cfg.pin(this@MainActivity)

        @JavascriptInterface
        fun logout() {
            Cfg.prefs(this@MainActivity).edit().remove("pin").apply()
            runOnUiThread { recreate() }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Cfg.pin(this).isEmpty()) loginUi() else webUi()
    }

    private fun loginUi() {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(60, 160, 60, 60)
        val t = TextView(this)
        t.text = "Owner login"
        t.textSize = 26f
        val e = EditText(this)
        e.hint = "PIN"
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val m = TextView(this)
        val bt = Button(this)
        bt.text = "Login"
        bt.setOnClickListener {
            val p = e.text.toString()
            m.text = "Checking..."
            Thread {
                val r = Cfg.api(p, "check")
                runOnUiThread {
                    if (r != null && r.contains("\"ok\":true")) {
                        Cfg.prefs(this).edit().putString("pin", p).apply()
                        webUi()
                    } else {
                        m.text = "Wrong PIN or no internet"
                    }
                }
            }.start()
        }
        l.addView(t); l.addView(e); l.addView(bt); l.addView(m)
        setContentView(l)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun webUi() {
        val w = WebView(this)
        web = w
        setContentView(w)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.addJavascriptInterface(Bridge(), "Android")
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.toString().startsWith(Cfg.SITE)) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        w.loadUrl(Cfg.SITE + "/" + Cfg.PAGE)
        FirebaseMessaging.getInstance().token.addOnSuccessListener { tk ->
            Thread { Cfg.api(Cfg.pin(this), "regtoken", "token" to tk) }.start()
        }
        askPerms()
    }

    private fun askPerms() {
        val p = Cfg.prefs(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !p.getBoolean("n", false)) {
            p.edit().putBoolean("n", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !p.getBoolean("b", false)) {
            p.edit().putBoolean("b", true).apply()
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent() && !p.getBoolean("f", false)) {
            p.edit().putBoolean("f", true).apply()
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        askPerms()
    }

    override fun onResume() {
        super.onResume()
        if (Cfg.pin(this).isNotEmpty()) askPerms()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }
}
