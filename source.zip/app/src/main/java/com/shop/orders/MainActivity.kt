package com.shop.orders

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.firebase.messaging.FirebaseMessaging
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val ctx: Context get() = this

    private fun js(cb: String, data: String) {
        runOnUiThread {
            web.evaluateJavascript("window.__cb(" + JSONObject.quote(cb) + "," + JSONObject.quote(data) + ")", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun shops(): String {
            val a = Cfg.shops(ctx)
            val o = JSONArray()
            for (i in 0 until a.length()) {
                val s = a.getJSONObject(i)
                o.put(JSONObject().put("id", s.getString("id")).put("name", s.getString("name")).put("url", s.getString("url")).put("panel", s.optString("panel")))
            }
            return o.toString()
        }

        @JavascriptInterface
        fun addShop(cb: String, name: String, url: String, panel: String, pin: String) {
            Thread {
                var u = url.trim()
                if (!u.startsWith("http")) u = "https://$u"
                u = u.trimEnd('/')
                val r = Cfg.api(u, pin, "check")
                val ok = r != null && r.contains("\"ok\":true")
                if (ok) {
                    val a = Cfg.shops(ctx)
                    a.put(JSONObject().put("id", System.currentTimeMillis().toString()).put("name", name.trim()).put("url", u).put("panel", panel.trim()).put("pin", pin))
                    Cfg.saveShops(ctx, a)
                    FirebaseMessaging.getInstance().token.addOnSuccessListener { Cfg.registerAll(ctx, it) }
                }
                js(cb, if (ok) "{\"ok\":true}" else "{\"ok\":false,\"err\":\"" + (if (r == null) "net" else "pin") + "\"}")
            }.start()
        }

        @JavascriptInterface
        fun updateShop(cb: String, id: String, name: String, url: String, panel: String, pin: String) {
            Thread {
                val old = Cfg.shop(ctx, id)
                if (old == null) {
                    js(cb, "{\"ok\":false,\"err\":\"net\"}")
                    return@Thread
                }
                var u = url.trim()
                if (!u.startsWith("http")) u = "https://$u"
                u = u.trimEnd('/')
                val p = if (pin.isEmpty()) old.getString("pin") else pin
                val r = Cfg.api(u, p, "check")
                val ok = r != null && r.contains("\"ok\":true")
                if (ok) {
                    val a = Cfg.shops(ctx)
                    for (i in 0 until a.length()) {
                        val s = a.getJSONObject(i)
                        if (s.getString("id") == id) {
                            s.put("name", name.trim()); s.put("url", u); s.put("panel", panel.trim()); s.put("pin", p)
                        }
                    }
                    Cfg.saveShops(ctx, a)
                    FirebaseMessaging.getInstance().token.addOnSuccessListener { Cfg.registerAll(ctx, it) }
                }
                js(cb, if (ok) "{\"ok\":true}" else "{\"ok\":false,\"err\":\"" + (if (r == null) "net" else "pin") + "\"}")
            }.start()
        }

        @JavascriptInterface
        fun removeShop(id: String) {
            val a = Cfg.shops(ctx)
            val n = JSONArray()
            for (i in 0 until a.length()) if (a.getJSONObject(i).getString("id") != id) n.put(a.getJSONObject(i))
            Cfg.saveShops(ctx, n)
        }

        @JavascriptInterface
        fun req(cb: String, id: String, action: String, params: String) {
            Thread {
                val s = Cfg.shop(ctx, id)
                var r: String? = null
                if (s != null) {
                    val kv = HashMap<String, String>()
                    val j = JSONObject(params)
                    for (k in j.keys()) kv[k] = j.getString(k)
                    r = Cfg.api(s.getString("url"), s.getString("pin"), action, kv)
                }
                js(cb, r ?: "")
            }.start()
        }

        @JavascriptInterface
        fun openPanel(id: String) {
            startActivity(Intent(ctx, PanelActivity::class.java).putExtra("id", id))
        }

        @JavascriptInterface
        fun testRing() {
            startForegroundService(Intent(ctx, RingService::class.java).putExtra("test", true))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/yup.html")
        FirebaseMessaging.getInstance().token.addOnSuccessListener { Cfg.registerAll(this, it) }
        askPerms()
    }

    private fun askPerms() {
        val p = Cfg.prefs(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED && !p.getBoolean("n", false)) {
            p.edit().putBoolean("n", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !p.getBoolean("b", false)) {
            p.edit().putBoolean("b", true).apply()
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent() && !p.getBoolean("f", false)) {
            p.edit().putBoolean("f", true).apply()
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        askPerms()
    }

    override fun onResume() {
        super.onResume()
        askPerms()
        web.evaluateJavascript("window.__resume&&window.__resume()", null)
    }
}
