package com.shop.orders

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

class RingService : Service() {
    companion object {
        @Volatile var active = false
        @Volatile var force = false
    }

    private var mp: MediaPlayer? = null
    private var vib: Vibrator? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") {
            stopAll()
            return START_NOT_STICKY
        }
        if (i?.action == "RECHECK") {
            force = true
            return START_NOT_STICKY
        }
        val test = i?.getBooleanExtra("test", false) == true
        val shop = i?.getStringExtra("shop") ?: ""
        val txt = if (test) "Test ring" else "New order" + (if (shop.isNotEmpty()) " - $shop" else "") + " - #" + (i?.getStringExtra("id") ?: "") + " - Rs " + (i?.getStringExtra("total") ?: "")
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ring", "Order alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(false)
            }
        )
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, RingActivity::class.java).putExtra("txt", txt).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), fl)
        val stop = PendingIntent.getService(this, 1, Intent(this, RingService::class.java).setAction("STOP"), fl)
        val n = Notification.Builder(this, "ring")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(txt)
            .setContentText("Tap to open")
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Silence", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(7, n)

        if (!active) {
            active = true
            wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yup:ring").apply { acquire(1800000L) }
            startRing()
            val t0 = System.currentTimeMillis()
            Thread {
                while (active) {
                    var w = 0
                    while (active && w < 4000 && !force) {
                        try { Thread.sleep(300) } catch (e: Exception) {}
                        w += 300
                    }
                    force = false
                    if (!active) break
                    val age = System.currentTimeMillis() - t0
                    if (test) {
                        if (age > 8000) break
                    } else {
                        // keep ringing only while a shop saved on THIS phone still has a new (unhandled) order
                        val a = Cfg.shops(this)
                        if (a.length() == 0) break
                        var reached = false
                        var pending = false
                        for (k in 0 until a.length()) {
                            val sh = a.getJSONObject(k)
                            val r = Cfg.api(sh.getString("url"), sh.getString("pin"), "ringstatus")
                            if (r != null && r.contains("\"ok\":true")) {
                                reached = true
                                if (!r.contains("\"n\":0")) pending = true
                            }
                        }
                        if (reached && !pending) break
                        if (!reached && age > 300000) break
                        if (age > 1800000) break
                    }
                }
                stopAll()
            }.start()
        }
        return START_NOT_STICKY
    }

    private fun startRing() {
        try {
            val am = getSystemService(AudioManager::class.java)
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, Math.round(mx * 0.9f), 0)
        } catch (e: Exception) {}
        try {
            val afd = resources.openRawResourceFd(R.raw.ring)
            mp = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {}
        vib = getSystemService(Vibrator::class.java)
        vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 900, 500), 0))
    }

    private fun stopAll() {
        active = false
        try { mp?.stop() } catch (e: Exception) {}
        mp?.release()
        mp = null
        vib?.cancel()
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        active = false
        mp?.release()
        vib?.cancel()
        super.onDestroy()
    }
}
