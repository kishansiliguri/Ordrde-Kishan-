package com.shop.orders

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

class RingService : Service() {
    companion object {
        @Volatile var active = false
    }

    private var mp: MediaPlayer? = null
    private var vib: Vibrator? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "STOP") {
            stopAll()
            return START_NOT_STICKY
        }
        val test = i?.getBooleanExtra("test", false) == true
        val txt = if (test) "Test ring" else "New order #" + (i?.getStringExtra("id") ?: "") + " - Rs " + (i?.getStringExtra("total") ?: "")
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ring", "Order alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(false)
            }
        )
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, RingActivity::class.java).putExtra("txt", txt).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), fl)
        val stop = PendingIntent.getService(this, 1, Intent(this, RingService::class.java).setAction("STOP"), fl)
        val n = Notification.Builder(this, "ring")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(txt)
            .setContentText("Tap to open")
            .setCategory(Notification.CATEGORY_ALARM)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Silence", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(7, n)

        if (!active) {
            active = true
            wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "orders:ring").apply { acquire(1800000L) }
            startRing()
            val t0 = System.currentTimeMillis()
            Thread {
                while (active) {
                    try { Thread.sleep(4000) } catch (e: Exception) {}
                    val age = System.currentTimeMillis() - t0
                    if (test) {
                        if (age > 8000) break
                    } else {
                        val r = Cfg.api(Cfg.pin(this), "ringstatus")
                        if ((r != null && r.contains("\"n\":0")) || age > 1800000) break
                    }
                }
                stopAll()
            }.start()
        }
        return START_NOT_STICKY
    }

    private fun startRing() {
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        try {
            mp = MediaPlayer().apply {
                setDataSource(this@RingService, uri)
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIC).build())
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {}
        vib = getSystemService(Vibrator::class.java)
        vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 900, 500), 0))
    }

    private fun stopAll() {
        active = false
        try { mp?.stop() } catch (e: Exception) {}
        mp?.release()
        mp = null
        vib?.cancel()
        try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) {}
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        active = false
        mp?.release()
        vib?.cancel()
        super.onDestroy()
    }
}
